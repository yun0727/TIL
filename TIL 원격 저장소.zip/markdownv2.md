## Git 기초 명령어

1. git init : 로컬 저장소 생성
2. git add <파일명> : 디렉토리 이동 (change directory)
3. git commit -m '<커밋 메시지>' : 커밋 (버전 기록)
4. git status : 상태 확인
5. git log : 버전 확인
